# SportyShoe

### This application is based on Springboot and Thymeleaf 


PROJECT DESCRIPTION :-
This application is designed and developed as an e-commerce portal sportyshoes.com for a walk-in store. This system allows Administrator to create(add), read(list), update and delete the customers of the application, categories and products of the application and to see the orders by customers. This project helps the administrator to manage the products and the customers well. The customer can login into the system as well as view the products added in the portal by the authorized admin. The customer can book the order the required shoes by paying online or cash only on delivery.
