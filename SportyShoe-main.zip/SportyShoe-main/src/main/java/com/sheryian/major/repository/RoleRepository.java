package com.sheryian.major.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sheryian.major.model.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {

}
